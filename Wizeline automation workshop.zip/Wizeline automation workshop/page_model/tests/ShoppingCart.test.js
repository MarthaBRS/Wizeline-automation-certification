import LoginPage from '../pages/LoginPage'
import ProductsPage from '../pages/ProductsPage'
import ShoppingCartPage from '../pages/ShoppingCartPage'
import { CREDENTIALS } from '../data/Constants'

fixture('Products feature testing')
    .page `https://www.saucedemo.com/`

test('User navigates to shopping cart page', async t =>{
    await LoginPage.submitLoginForm(CREDENTIALS.VALID_USER.USERNAME, CREDENTIALS.VALID_USER.PASSWORD)
    await t.expect(ProductsPage.productlabel.exists).ok()
    await t.expect(ProductsPage.productlabel.innerText).eql('Products')
        
    await t
            .click(ProductsPage.shoppingcartbutton)
        
    await t.expect(ShoppingCartPage.yourcartlabel.exists).ok()
})  

test('User add a single item to the shopping cart', async t =>{
    await LoginPage.submitLoginForm(CREDENTIALS.VALID_USER.USERNAME, CREDENTIALS.VALID_USER.PASSWORD)
    await t.expect(ProductsPage.productlabel.exists).ok()
    await t.expect(ProductsPage.productlabel.innerText).eql('Products')
        
    await t
            .click(ProductsPage.addtocartbutton.nth(0))

    await t.expect(ProductsPage.shoppingcartbadgeqty.exists).ok()

    await t
            .click(ProductsPage.shoppingcartbutton)
        
    await t.expect(ShoppingCartPage.yourcartlabel.exists).ok()
    await t.expect(ShoppingCartPage.qtybutton.nth(0).exists).ok()
    await t.expect(ShoppingCartPage.qtybutton.nth(0).innerText).eql('1')
    await t.expect(ShoppingCartPage.removebutton.nth(0).exists).ok()
    await t.expect(ShoppingCartPage.qtybutton.nth(1).exists).notOk()
    await t.expect(ShoppingCartPage.removebutton.nth(1).exists).notOk()

})  

test('User add multiple items to the shopping cart', async t =>{
        await LoginPage.submitLoginForm(CREDENTIALS.VALID_USER.USERNAME, CREDENTIALS.VALID_USER.PASSWORD)
        await t.expect(ProductsPage.productlabel.exists).ok()
        await t.expect(ProductsPage.productlabel.innerText).eql('Products')

//const itemone =  await ProductsPage.itemdescription.nth(0).innerText
//const itemtwo =  await ProductsPage.itemdescription.nth(1).innerText
//const itemthree =  await ProductsPage.itemdescription.nth(2).innerText

        await t
                .click(ProductsPage.addtocartbutton.nth(0))
                .click(ProductsPage.addtocartbutton.nth(1))
                .click(ProductsPage.addtocartbutton.nth(2))
        

        await t.expect(ProductsPage.shoppingcartbadgeqty.exists).ok()
        await t.expect(ProductsPage.shoppingcartbadgeqty.innerText).eql('3')

        await t
                .click(ProductsPage.shoppingcartbutton)

        //Validate the same products added are in the shopping cart
        await t.expect(ShoppingCartPage.yourcartlabel.exists).ok()
        await t.expect(ProductsPage.itemdescription.nth(0).innerText).eql('Sauce Labs Backpack')
        await t.expect(ProductsPage.itemdescription.nth(1).innerText).eql('Sauce Labs Bolt T-Shirt')
        await t.expect(ProductsPage.itemdescription.nth(2).innerText).eql('Sauce Labs Onesie')

})  

