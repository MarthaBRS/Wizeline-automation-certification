import LoginPage from '../pages/LoginPage'
import ProductsPage from '../pages/ProductsPage'
import { CREDENTIALS } from '../data/Constants'

fixture('Login feature testing')
    .page `https://www.saucedemo.com/`

test('Users can login with valid user', async t =>{
    await LoginPage.submitLoginForm(CREDENTIALS.VALID_USER.USERNAME, CREDENTIALS.VALID_USER.PASSWORD)
    await t.expect(ProductsPage.productlabel.exists).ok()
})

test('Users cannot login with invalid user', async t =>{
    await t
        .typeText(LoginPage.username, CREDENTIALS.INVALID_USER.USERNAME)
        .typeText(LoginPage.password, CREDENTIALS.INVALID_USER.PASSWORD)
        .click(LoginPage.loginbutton)

    await t.expect(LoginPage.errormsg.exists).ok()
    await t.expect(LoginPage.errormsg.innerText).eql('Epic sadface: Username and password do not match any user in this service')  
})


