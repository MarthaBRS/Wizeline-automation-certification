import LoginPage from '../pages/LoginPage'
import ProductsPage from '../pages/ProductsPage'
import { CREDENTIALS } from '../data/Constants'

fixture('Products feature testing')
    .page `https://www.saucedemo.com/`

test('User logout from Products page', async t =>{
    await LoginPage.submitLoginForm(CREDENTIALS.VALID_USER.USERNAME, CREDENTIALS.VALID_USER.PASSWORD)
    await t.expect(ProductsPage.productlabel.exists).ok()
    await t.expect(ProductsPage.productlabel.innerText).eql('Products')

    await t
            .click(ProductsPage.burgermenubutton)
            .click(ProductsPage.logoutbutton)
    
    await t.expect(LoginPage.loginbutton.exists).ok()
})
