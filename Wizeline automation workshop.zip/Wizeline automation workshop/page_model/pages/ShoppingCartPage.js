import {Selector} from 'testcafe'

class ShoppingCartPage{
    constructor(){
        this.yourcartlabel = Selector('.subheader')
        this.checkoutbutton = Selector ('.checkout_button').withExactText('CHECKOUT')
        this.qtybutton = Selector ('.cart_quantity')
        this.removebutton = Selector ('.cart_button').withExactText('REMOVE')
        this.firstnamefield = Selector ('#first-name.form_input')
        this.lastnamefield = Selector ('#last-name.form_input')
        this.zipcodefield = Selector ('#postal-code.form_input')
        this.errormsgzipcode = Selector ('h3').withExactText('Error: Postal Code is required')
        this.continuebutton = Selector ('input.btn_primary.cart_button')
        this.checkoutheader = Selector ('.subheader').withExactText('Checkout: Your Information')
        this.overviewheader = Selector ('.subheader').withExactText('Checkout: Overview')
        this.finishpurchasebtn = Selector ('.btn_action.cart_button').withExactText('FINISH')
        this.confirmationpage = Selector ('h2.complete-header').withExactText('THANK YOU FOR YOUR ORDER')
    }
}

export default new ShoppingCartPage()