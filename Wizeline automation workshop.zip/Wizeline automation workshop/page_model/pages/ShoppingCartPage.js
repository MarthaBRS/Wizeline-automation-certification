import {Selector} from 'testcafe'

class ShoppingCartPage{
    constructor(){
        this.yourcartlabel = Selector('.subheader')
        this.checkoutbutton = Selector ('.checkout_button').withExactText('CHECKOUT')
        this.qtybutton = Selector ('.cart_quantity')
        this.removebutton = Selector ('.cart_button').withExactText('REMOVE')
    }
}

export default new ShoppingCartPage()