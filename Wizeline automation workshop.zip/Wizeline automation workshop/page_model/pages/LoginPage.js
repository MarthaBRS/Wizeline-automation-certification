import {Selector, t} from 'testcafe'

class LoginPage{
    constructor() {
        this.username = Selector('input[name="user-name"]');
        this.password = Selector('input[name="password"]');
        this.loginbutton = Selector('.btn_action');
        this.errormsg = Selector('h3');
    }

    async submitLoginForm(usernameval, passwordval){
        await t
                .typeText(this.username, usernameval)
                .typeText(this.password, passwordval)
                .click(this.loginbutton)
    }
}

export default new LoginPage()