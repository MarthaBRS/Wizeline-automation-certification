import {Selector} from 'testcafe'

class ProductsPage{
    constructor(){
        this.productlabel = Selector('.product_label')
        this.burgermenubutton = Selector('#react-burger-menu-btn')
        this.logoutbutton = Selector ('#logout_sidebar_link.bm-item.menu-item')
        this.shoppingcartbutton = Selector ('.fa-shopping-cart')
        this.addtocartbutton = Selector ('.btn_primary.btn_inventory')
        this.shoppingcartbadgeqty = Selector ('.shopping_cart_badge')
        this.itemdescription = Selector ('.inventory_item_name')
    }
}

export default new ProductsPage()